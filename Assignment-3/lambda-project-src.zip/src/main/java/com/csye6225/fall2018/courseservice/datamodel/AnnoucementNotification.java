package com.csye6225.fall2018.courseservice.datamodel;


import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.DynamodbEvent;
import com.amazonaws.services.lambda.runtime.events.DynamodbEvent.DynamodbStreamRecord;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;

public class AnnoucementNotification implements RequestHandler<DynamodbEvent, String> {
	DynamoDBMapper mapper;
	Table dynamoDBTable;
	SNSTopic snsTopic;
	AmazonSNS snsClientObject;
	
	@Override
    public String handleRequest(DynamodbEvent dynamodbEvent, Context context) {
		String output="";
    	 for (DynamodbStreamRecord record : dynamodbEvent.getRecords()) {
    		 if(record.getEventName().equals("INSERT")) {
    			 String announcementText=record.getDynamodb().getNewImage().get("announcementText").getS();
    			 String boardId=record.getDynamodb().getNewImage().get("boardId").getN();
    			 
    			 String retrievedTopicARN=getSNSTopicARN("board",Long.parseLong(boardId));
    			 
    			 snsClientObject = AmazonSNSClientBuilder.standard().withRegion(Regions.US_WEST_2)
    						.withCredentials(DefaultAWSCredentialsProviderChain.getInstance()).build();
    			
    			 PublishRequest publishRequest = new PublishRequest(retrievedTopicARN, announcementText);
    			 PublishResult publishResult = snsClientObject.publish(publishRequest);
    			 output+=publishResult.getMessageId();
    		 }
    		}
    	 context.getLogger().log("Successful");
		 output+="Successfully sent annoucement";
		 return output;
    }
	public AmazonDynamoDB getClient() {
		return AmazonDynamoDBClientBuilder.standard().withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
				.withRegion("us-west-2").build();
	}

	private String getSNSTopicARN(String tableName,long queryId) {
		DynamoDB dynamoDB = new DynamoDB(getClient());
		dynamoDBTable = dynamoDB.getTable("board");
		mapper = new DynamoDBMapper(getClient());
		
		Board retrievedBoardObject=mapper.load(Board.class,queryId);
		
		Long courseIdToQuery=retrievedBoardObject.getCourseId();
		
		dynamoDBTable = dynamoDB.getTable("course");
		mapper = new DynamoDBMapper(getClient());
		Course courseObject=mapper.load(Course.class,courseIdToQuery);
		String topicArn=courseObject.getCourseSNSTopic();
		return topicArn;
		
	}

}
