package com.csye6225.fall2018.courseservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.csye6225.fall2018.courseservice.datamodel.Announcement;
import com.csye6225.fall2018.courseservice.datamodel.DynamoDBConnector;

public class AnnouncementService {
	static DynamoDBConnector dynamoDbConnector;
	DynamoDBMapper mapper;
	Table dynamoDBTable;
	DynamoDB dynamoDB;

	public AnnouncementService() {
		dynamoDbConnector = new DynamoDBConnector();
		dynamoDbConnector.init();
		dynamoDB = new DynamoDB(dynamoDbConnector.getClient());
		dynamoDBTable = dynamoDB.getTable("announcement");
		mapper = new DynamoDBMapper(dynamoDbConnector.getClient());
	}

	// Getting a list of all boards
	// GET "..webapi/boards"
	public List<Announcement> getAllAnnouncements() {
		ArrayList<Announcement> allAnnouncementsList = new ArrayList<>();
		ScanRequest scanRequest = new ScanRequest().withTableName("announcement");
		ScanResult result = dynamoDbConnector.getClient().scan(scanRequest);
		for (Map<String, AttributeValue> item : result.getItems()) {
			Announcement announcementObject = new Announcement(Long.parseLong(item.get("announcementId").getN()),
					item.get("announcementText").getS(), Long.parseLong(item.get("boardId").getN()));
			allAnnouncementsList.add(announcementObject);
		}
		return allAnnouncementsList;
	}

	public Announcement addAnnouncement(Announcement announcement) {
		String checkString = announcement.getAnnouncementText();
		char[] checkArray = checkString.toCharArray();
		if (checkArray.length > 160) {
			System.out.println("Cannot add announcement");
			return new Announcement();
		} else {
			Random rand = new Random();
			long randomNumber = Math.abs(rand.nextLong());
			announcement.setAnnouncementId(randomNumber);
			mapper.save(announcement);
			return announcement;
		}
	}

	// Getting One Announcement
	public Announcement getAnnouncement(long announcementId) {
		Announcement announcementObject = mapper.load(Announcement.class, announcementId);
		return announcementObject;
	}

	// Deleting a Announcement
	public Announcement deleteAnnouncement(long announcementId) {
		Announcement deletedAnnouncement = mapper.load(Announcement.class, announcementId);
		mapper.delete(deletedAnnouncement);
		return deletedAnnouncement;
	}

	// Updating Announcement Info
	public Announcement updateAnnouncementDetails(long announcementId, Announcement announcement) {
		Announcement oldAnnouncementObject = mapper.load(Announcement.class, announcementId);
		oldAnnouncementObject.setAnnouncementText(announcement.getAnnouncementText());
		mapper.save(oldAnnouncementObject);
		return oldAnnouncementObject;
	}
}
