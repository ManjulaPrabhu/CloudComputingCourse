package com.csye6225.fall2018.courseservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.csye6225.fall2018.courseservice.datamodel.Board;
import com.csye6225.fall2018.courseservice.datamodel.DynamoDBConnector;

public class BoardService {
	static DynamoDBConnector dynamoDbConnector;
	DynamoDBMapper mapper;
	Table dynamoDBTable;
	DynamoDB dynamoDB;

	public BoardService() {
		dynamoDbConnector = new DynamoDBConnector();
		dynamoDbConnector.init();
		dynamoDB = new DynamoDB(dynamoDbConnector.getClient());
		dynamoDBTable = dynamoDB.getTable("board");
		mapper = new DynamoDBMapper(dynamoDbConnector.getClient());
	}

	// Getting a list of all boards
	// GET "..webapi/boards"
	public List<Board> getAllBoards() {
		ArrayList<Board> allBoardsList = new ArrayList<>();
		ScanRequest scanRequest = new ScanRequest().withTableName("board");
		ScanResult result = dynamoDbConnector.getClient().scan(scanRequest);
		for (Map<String, AttributeValue> item : result.getItems()) {

			Board boardObject = new Board(Long.parseLong(item.get("boardId").getN()),
					Long.parseLong(item.get("courseId").getN()));
			allBoardsList.add(boardObject);
		}
		return allBoardsList;
	}

	public Board addBoard(Board board) {
		Random rand = new Random();
		long randomNumber = Math.abs(rand.nextLong());
		board.setBoardId(randomNumber);
		mapper.save(board);
		return board;
	}

	// Getting One Board
	public Board getBoard(long boardId) {
		Board boardObject = mapper.load(Board.class, boardId);
		return boardObject;
	}

	// Deleting a board
	public Board deleteBoard(long boardId) {
		Board deletedBoard = mapper.load(Board.class, boardId);
		mapper.delete(deletedBoard);
		return deletedBoard;
	}

	// Updating Board Info
	public Board updateBoardDetails(long boardId, Board board) {
		Board oldBoardObject = mapper.load(Board.class, boardId);
		oldBoardObject.setCourseId(board.getCourseId());
		mapper.save(oldBoardObject);
		return oldBoardObject;
	}
}
