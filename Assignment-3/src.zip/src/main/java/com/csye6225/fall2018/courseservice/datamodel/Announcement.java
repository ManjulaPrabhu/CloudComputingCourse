package com.csye6225.fall2018.courseservice.datamodel;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "announcement")
public class Announcement {
	private long announcementId;
	private String announcementText;
	private long boardId;

	public Announcement() {

	}

	public Announcement(long announcementId, String announcementText, long boardId) {
		this.announcementId = announcementId;
		this.announcementText = announcementText;
		this.boardId = boardId;
	}

	@DynamoDBHashKey(attributeName = "announcementId")
	public long getAnnouncementId() {
		return announcementId;
	}

	public void setAnnouncementId(long announcementId) {
		this.announcementId = announcementId;
	}

	@DynamoDBAttribute(attributeName = "announcementText")
	public String getAnnouncementText() {
		return announcementText;
	}

	public void setAnnouncementText(String announcementText) {
		this.announcementText = announcementText;
	}

	@DynamoDBAttribute(attributeName = "boardId")
	public long getBoardId() {
		return boardId;
	}

	public void setBoardId(long boardId) {
		this.boardId = boardId;
	}

	@DynamoDBIgnore
	@Override
	public String toString() {
		return "AnnouncementID=" + getAnnouncementId() + ", announcementText=" + getAnnouncementText() + ", boardId="
				+ getBoardId();
	}
}
