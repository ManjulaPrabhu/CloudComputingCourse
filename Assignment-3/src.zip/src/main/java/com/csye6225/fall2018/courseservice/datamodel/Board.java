package com.csye6225.fall2018.courseservice.datamodel;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "board")
public class Board {
	private long boardId;
	private long courseId;

	public Board() {

	}

	public Board(long boardId, long courseId) {
		this.boardId = boardId;
		this.courseId = courseId;
	}

	@DynamoDBHashKey(attributeName = "boardId")
	public long getBoardId() {
		return boardId;
	}

	public void setBoardId(long boardId) {
		this.boardId = boardId;
	}

	@DynamoDBAttribute(attributeName = "courseId")
	public long getCourseId() {
		return courseId;
	}

	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}

	@DynamoDBIgnore
	@Override
	public String toString() {
		return "BoardID=" + getBoardId() + ", courseId=" + getCourseId();
	}

}
