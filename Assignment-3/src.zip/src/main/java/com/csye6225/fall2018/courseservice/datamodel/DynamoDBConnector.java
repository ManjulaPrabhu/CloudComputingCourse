package com.csye6225.fall2018.courseservice.datamodel;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;

public class DynamoDBConnector {
	static AmazonDynamoDB dynamoDB;

	public static void init() {
		if (dynamoDB == null) {
			dynamoDB = AmazonDynamoDBClientBuilder.standard().withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
					.withRegion("us-west-2").build();
			
			System.out.println("\nClient Created\n");
		}
	}

	public AmazonDynamoDB getClient() {
		return dynamoDB;
	}

}
