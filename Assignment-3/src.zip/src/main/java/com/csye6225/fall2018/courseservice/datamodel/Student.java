package com.csye6225.fall2018.courseservice.datamodel;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "student")
public class Student {
	private long studentId;
	private String firstName;
	private String emailId;
	private List<Long> associatedCourses;
	private String enrolledProgramName;

	public Student() {

	}

	public Student(long studentId, String firstName, String emailId, List<Long> associatedCourses,
			String enrolledProgramName) {
		this.studentId = studentId;
		this.firstName = firstName;
		this.emailId = emailId;
		this.associatedCourses = associatedCourses;
		this.enrolledProgramName = enrolledProgramName;
	}

	@DynamoDBHashKey(attributeName = "studentId")
	public long getStudentId() {
		return studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	@DynamoDBAttribute(attributeName = "firstName")
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@DynamoDBAttribute(attributeName = "associatedCourses")
	public List<Long> getAssociatedCourses() {
		return associatedCourses;
	}

	public void setAssociatedCourses(List<Long> associatedCourses) {
		this.associatedCourses = associatedCourses;
	}

	@DynamoDBAttribute(attributeName = "enrolledProgramName")
	public String getEnrolledProgramName() {
		return enrolledProgramName;
	}

	public void setEnrolledProgramName(String enrolledProgramName) {
		this.enrolledProgramName = enrolledProgramName;
	}

	@DynamoDBAttribute(attributeName = "emailId")
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@DynamoDBIgnore
	@Override
	public String toString() {
		return "StudentID=" + getStudentId() + ", firstName=" + getFirstName() + ", associatedCourses="
				+ getAssociatedCourses() + ", enrolledProgramName=" + getEnrolledProgramName();
	}

}
