package com.csye6225.fall2018.courseservice.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.csye6225.fall2018.courseservice.datamodel.Announcement;
import com.csye6225.fall2018.courseservice.service.AnnouncementService;

//.. /webapi/myresource
@Path("announcements")
public class AnnouncementResource {
	AnnouncementService announcementServiceObject = new AnnouncementService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Announcement> getAllAnnouncements() {
		return announcementServiceObject.getAllAnnouncements();
	}

	// ... webapi/announcement/1/2
	@GET
	@Path("/{announcementId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Announcement getAnnouncement(@PathParam("announcementId") long announcementId) {
		return announcementServiceObject.getAnnouncement(announcementId);
	}

	@DELETE
	@Path("/{announcementId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Announcement deleteAnnouncement(@PathParam("announcementId") long announcementId) {
		return announcementServiceObject.deleteAnnouncement(announcementId);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Announcement addAnnouncement(Announcement announcement) {
		return announcementServiceObject.addAnnouncement(announcement);
	}

	@PUT
	@Path("/{announcementId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Announcement updateAnnouncement(@PathParam("announcementId") long announcementId,
			Announcement announcement) {
		return announcementServiceObject.updateAnnouncementDetails(announcementId, announcement);
	}

}
