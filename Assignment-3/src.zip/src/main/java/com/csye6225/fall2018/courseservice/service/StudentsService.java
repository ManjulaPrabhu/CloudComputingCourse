package com.csye6225.fall2018.courseservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.validator.routines.EmailValidator;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.SubscribeRequest;
import com.csye6225.fall2018.courseservice.datamodel.Course;
import com.csye6225.fall2018.courseservice.datamodel.DynamoDBConnector;
import com.csye6225.fall2018.courseservice.datamodel.SNSTopic;
import com.csye6225.fall2018.courseservice.datamodel.Student;

public class StudentsService {
	static DynamoDBConnector dynamoDbConnector;
	DynamoDBMapper mapper;
	Table dynamoDBTable;
	DynamoDB dynamoDB;
	SNSTopic snsTopic;
	AmazonSNS snsClientObject;

	public StudentsService() {
		dynamoDbConnector = new DynamoDBConnector();
		dynamoDbConnector.init();
		dynamoDB = new DynamoDB(dynamoDbConnector.getClient());
		dynamoDBTable = dynamoDB.getTable("student");
		mapper = new DynamoDBMapper(dynamoDbConnector.getClient());

		snsTopic = new SNSTopic();
		snsClientObject = snsTopic.getClient();
	}

	// Getting a list of all students
	// GET "..webapi/students"
	public List<Student> getAllStudents() {
		ArrayList<Student> allStudentsList = new ArrayList<>();
		ScanRequest scanRequest = new ScanRequest().withTableName("student");
		ScanResult result = dynamoDbConnector.getClient().scan(scanRequest);
		for (Map<String, AttributeValue> item : result.getItems()) {
			List<AttributeValue> tempList = new ArrayList<>(item.get("associatedCourses").getL());
			List<Long> associatedCourseList = new ArrayList<>();

			for (AttributeValue eachCourse : tempList) {
				associatedCourseList.add(Long.parseLong(eachCourse.getN()));
			}

			Student studentObject = new Student(Long.parseLong(item.get("studentId").getN()),
					item.get("firstName").getS(), item.get("emailId").getS(), associatedCourseList,
					item.get("enrolledProgramName").getS());
			allStudentsList.add(studentObject);
		}
		return allStudentsList;
	}

	public Student addStudent(Student student) {
		Random rand = new Random();
		long randomNumber = Math.abs(rand.nextLong());
		student.setStudentId(randomNumber);
		student.setAssociatedCourses(new ArrayList<Long>());
		if (checkEmailValidity(student.getEmailId())) {
			mapper.save(student);
			return student;
		}
		return new Student();
	}

	private boolean checkEmailValidity(String emailId) {
		try {
			boolean valid = EmailValidator.getInstance().isValid(emailId);
			return valid;
		} catch (Exception e) {
			return false;
		}

	}

	// Getting One Student
	public Student getStudent(long studentId) {
		Student studentObject = mapper.load(Student.class, studentId);
		return studentObject;
	}

	// Deleting a student
	public Student deleteStudent(long studentId) {
		Student deletedStudent = mapper.load(Student.class, studentId);
		mapper.delete(deletedStudent);
		return deletedStudent;
	}

	// Updating Student Info
	public Student updateStudentDetails(long studentId, Student student) {
		Student oldStudentObject = mapper.load(Student.class, studentId);
		oldStudentObject.setFirstName(student.getFirstName());
		oldStudentObject.setAssociatedCourses(student.getAssociatedCourses());
		oldStudentObject.setEnrolledProgramName(student.getEnrolledProgramName());

		if (checkEmailValidity(student.getEmailId())) {
			oldStudentObject.setEmailId(student.getEmailId());
			mapper.save(oldStudentObject);
			return oldStudentObject;
		}
		return new Student();
	}

	// Registering to Courses
	public Student registerToCourses(Long studentId, List<Long> courseIdList) {
		CourseService courseServiceObject=new CourseService();
		if (courseIdList.size() <= 3) {
			Student objectToBeUpdated = mapper.load(Student.class, studentId);
			String studentEmail = objectToBeUpdated.getEmailId();
			List<Long> coursesToBeChecked = objectToBeUpdated.getAssociatedCourses();
			for (Long eachCourse : courseIdList) {
				if (!coursesToBeChecked.contains(eachCourse)) {
					coursesToBeChecked.add(eachCourse);
					courseServiceObject.updateRegisteredStudents(eachCourse, studentId);
				}
			}
			objectToBeUpdated.setAssociatedCourses(coursesToBeChecked);
			mapper.save(objectToBeUpdated);
			subscribeToSNSTopic(courseIdList, studentEmail);
			return objectToBeUpdated;
		} else {
			return new Student();
		}
	}

	private void subscribeToSNSTopic(List<Long> courseIdList, String studentEmail) {
		for (Long eachCourse : courseIdList) {
			String subscribeTopic = queryCourseARN(eachCourse);
			SubscribeRequest subRequest = new SubscribeRequest(subscribeTopic, "email", studentEmail);
			snsClientObject.subscribe(subRequest);
		}

	}

	private String queryCourseARN(long eachCourse) {
		Course queriedCourseObject = mapper.load(Course.class, eachCourse);
		return queriedCourseObject.getCourseSNSTopic();
	}
}
