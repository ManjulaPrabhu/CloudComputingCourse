package com.csye6225.fall2018.courseservice.datamodel;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;

public class SNSTopic {

	static AmazonSNS snsClient;

	public AmazonSNS getClient() {
		snsClient = AmazonSNSClientBuilder.standard().withRegion(Regions.US_WEST_2)
				.withCredentials(DefaultAWSCredentialsProviderChain.getInstance()).build();
		return snsClient;
	}

}
