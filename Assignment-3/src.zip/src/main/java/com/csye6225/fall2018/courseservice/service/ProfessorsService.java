package com.csye6225.fall2018.courseservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.csye6225.fall2018.courseservice.datamodel.DynamoDBConnector;
import com.csye6225.fall2018.courseservice.datamodel.Professor;

public class ProfessorsService {
	static DynamoDBConnector dynamoDbConnector;
	DynamoDBMapper mapper;
	Table dynamoDBTable;
	DynamoDB dynamoDB;

	public ProfessorsService() {
		dynamoDbConnector = new DynamoDBConnector();
		dynamoDbConnector.init();
		dynamoDB = new DynamoDB(dynamoDbConnector.getClient());
		dynamoDBTable = dynamoDB.getTable("professor");
		mapper = new DynamoDBMapper(dynamoDbConnector.getClient());
	}

	// Getting a list of all professor
	// GET "..webapi/professors"
	public List<Professor> getAllProfessors() {
		// Getting the list
		ArrayList<Professor> list = new ArrayList<>();
		ScanRequest scanRequest = new ScanRequest().withTableName("professor");
		ScanResult result = dynamoDbConnector.getClient().scan(scanRequest);
		for (Map<String, AttributeValue> item : result.getItems()) {
			Professor professorObject = new Professor(Long.parseLong(item.get("professorId").getN()),
					item.get("firstName").getS(), item.get("department").getS(), item.get("joiningDate").getS());
			list.add(professorObject);
		}
		return list;
	}

	public Professor addProfessor(Professor prof) {
		Random rand = new Random();
		long randomNumber = Math.abs(rand.nextLong());
		prof.setProfessorId(randomNumber);
		mapper.save(prof);
		return prof;
	}

	// Getting One Professor
	public Professor getProfessor(long professorId) {
		Professor professorObject = mapper.load(Professor.class, professorId);
		return professorObject;
	}

	// Deleting a professor
	public Professor deleteProfessor(long professorId) {
		Professor deletedProfObject = mapper.load(Professor.class, professorId);
		mapper.delete(deletedProfObject);
		return deletedProfObject;
	}

	// Updating Professor Info
	public Professor updateProfessorInformation(long professorId, Professor prof) {
		Professor oldProfObject = mapper.load(Professor.class, professorId);
		oldProfObject.setFirstName(prof.getFirstName());
		oldProfObject.setDepartment(prof.getDepartment());
		oldProfObject.setJoiningDate(prof.getJoiningDate());
		mapper.save(oldProfObject);

		return oldProfObject;
	}
}
