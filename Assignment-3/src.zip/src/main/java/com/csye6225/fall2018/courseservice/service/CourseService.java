package com.csye6225.fall2018.courseservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.CreateTopicRequest;
import com.amazonaws.services.sns.model.CreateTopicResult;
import com.csye6225.fall2018.courseservice.datamodel.Course;
import com.csye6225.fall2018.courseservice.datamodel.DynamoDBConnector;
import com.csye6225.fall2018.courseservice.datamodel.SNSTopic;

public class CourseService {
	static DynamoDBConnector dynamoDbConnector;
	SNSTopic snsTopic;
	DynamoDBMapper mapper;
	Table dynamoDBTable;
	DynamoDB dynamoDB;
	AmazonSNS snsClientObject;

	public CourseService() {
		dynamoDbConnector = new DynamoDBConnector();
		dynamoDbConnector.init();
		dynamoDB = new DynamoDB(dynamoDbConnector.getClient());
		dynamoDBTable = dynamoDB.getTable("course");
		mapper = new DynamoDBMapper(dynamoDbConnector.getClient());

		snsTopic = new SNSTopic();
		snsClientObject = snsTopic.getClient();

	}

	// Getting a list of all courses
	// GET "..webapi/courses"
	public List<Course> getAllCourses() {
		// Getting the list
		ArrayList<Course> allCoursesList = new ArrayList<>();
		ScanRequest scanRequest = new ScanRequest().withTableName("course");
		ScanResult result = dynamoDbConnector.getClient().scan(scanRequest);
		for (Map<String, AttributeValue> item : result.getItems()) {
			List<AttributeValue> tempLectureList = new ArrayList<>(item.get("associatedLectureId").getL());
			List<AttributeValue> tempStudentsList = new ArrayList<>(item.get("associatedStudentsId").getL());

			List<Long> associatedLectures = new ArrayList<>();
			List<Long> associatedStudents = new ArrayList<>();
			for (AttributeValue eachLecture : tempLectureList) {
				associatedLectures.add(Long.parseLong(eachLecture.getN()));
			}
			for (AttributeValue eachStudent : tempStudentsList) {
				associatedStudents.add(Long.parseLong(eachStudent.getN()));
			}

			Course courseObject = new Course(Long.parseLong(item.get("courseId").getN()), item.get("courseName").getS(),
					associatedLectures, associatedStudents, Long.parseLong(item.get("associatedProfessorId").getN()),
					Long.parseLong(item.get("boardId").getN()), Long.parseLong(item.get("associatedTAId").getN()),
					item.get("courseSNSTopic").getS());

			allCoursesList.add(courseObject);
		}
		return allCoursesList;
	}

	// Adding a course
	public Course addCourse(Course course) {
		Random rand = new Random();
		long randomNumber = Math.abs(rand.nextLong());
		course.setCourseId(randomNumber);

		// Creating a topic for the added Course
		String topicARNToAssign = createSNSTopic(randomNumber);
		course.setCourseSNSTopic(topicARNToAssign);

		mapper.save(course);
		return course;
	}

	private String createSNSTopic(long randomNumber) {
		String topicName = "Topic" + String.valueOf(randomNumber);
		CreateTopicRequest createTopicRequest = new CreateTopicRequest(topicName);

		CreateTopicResult createTopicResult = snsClientObject.createTopic(createTopicRequest);
		return createTopicResult.getTopicArn();
	}

	// Getting One Course
	public Course getCourse(long courseId) {
		Course courseObject = mapper.load(Course.class, courseId);
		return courseObject;
	}

	// Deleting a course
	public Course deleteCourse(long courseId) {
		Course deletedCourse = mapper.load(Course.class, courseId);
		mapper.delete(deletedCourse);
		return deletedCourse;
	}

	// Updating Course Info
	public Course updateCourse(long courseId, Course course) {
		Course oldCourseObject = mapper.load(Course.class, courseId);
		oldCourseObject.setCourseName(course.getCourseName());
		oldCourseObject.setAssociatedLectureId(course.getAssociatedLectureId());
		oldCourseObject.setAssociatedStudentsId(course.getAssociatedStudentsId());
		oldCourseObject.setAssociatedProfessorId(course.getAssociatedProfessorId());
		oldCourseObject.setAssociatedTAId(course.getAssociatedTAId());
		oldCourseObject.setBoardId(course.getBoardId());
		oldCourseObject.setCourseSNSTopic(course.getCourseSNSTopic());

		mapper.save(oldCourseObject);

		return oldCourseObject;
	}
	
	public void updateRegisteredStudents(long courseId,long studentId) {
		Course courseObjectToUpdate=mapper.load(Course.class,courseId);
		List<Long> retrievedStudentsList=courseObjectToUpdate.getAssociatedStudentsId();
		retrievedStudentsList.add(studentId);
		courseObjectToUpdate.setAssociatedStudentsId(retrievedStudentsList);
		mapper.save(courseObjectToUpdate);
	}

}
